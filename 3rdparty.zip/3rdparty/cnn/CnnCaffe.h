/**
 * @file CnnCaffe.h
 * @author: Kuang Fangjun <csukuangfj at gmail dot com>
 * @date August 10, 2018
 *
 */

#ifndef LANE_LINE_CNNCAFFE_H
#define LANE_LINE_CNNCAFFE_H

#include <string>
#include <vector>

#include "cnn/CnnInterface.h"

namespace tt
{


class CnnCaffe : public CnnInterface
{
 public:
    bool init(
            const std::string &proto_file,
            const std::string &trained_file,
            int gpu_id) override;

    void forward(const cv::Mat &image,
                 std::vector<cv::Mat> *result) override;

    bool getBlobByName(
            const std::string &blob_name,
            boost::shared_ptr<caffe::Blob<float>> *blob) override;

    bool getBlobShapeByName(
            const std::string &blob_name,
            std::vector<int> *blob_shape) override;

    bool setBlobShapeByName(
            const std::string &blob_name,
            const std::vector<int> &blob_shape) override;

 private:
    std::shared_ptr<caffe::Net<float> > net_;
    std::vector<cv::Mat> input_data_;
    caffe::Blob<float>* input_blob_;
    caffe::Blob<float>* output_blob_;
};

}  // namespace tt


#endif  // LANE_LINE_CNNCAFFE_H

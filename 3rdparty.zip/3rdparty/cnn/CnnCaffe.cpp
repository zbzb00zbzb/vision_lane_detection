/**
 * @file CnnCaffe.cpp
 * @author: Kuang Fangjun <csukuangfj at gmail dot com>
 * @date August 10, 2018
 *
 */

#include <opencv2/core.hpp>

#include <string>
#include <vector>

#include "cnn/CnnCaffe.h"

#include "lane_line/FileSystem.h"

namespace tt
{

bool CnnCaffe::init(const std::string &proto_file,
                    const std::string &trained_file,
                    int gpu_id)
{
    CHECK(FileSystem::fileExists(proto_file))
    << "File " << proto_file << " does not exist!";

    CHECK(FileSystem::fileExists(trained_file))
    << "File " << trained_file << " does not exist!";

    if (gpu_id >= 0)    // TODO: check that gpu_id is valid
    {
        caffe::Caffe::set_mode(caffe::Caffe::GPU);
        caffe::Caffe::SetDevice(gpu_id);
        caffe::Caffe::DeviceQuery();
    }
    else    // NOLINT
    {
        LOG(WARNING) << "Use CPU!";
        caffe::Caffe::set_mode(caffe::Caffe::CPU);
    }

    net_ = std::make_shared<caffe::Net<float>>(proto_file, caffe::TEST);
    CHECK_NOTNULL(net_.get());
    net_->CopyTrainedLayersFrom(trained_file);

#if 0
    boost::shared_ptr<caffe::Blob<float>> input_blob;
    if (getBlobByName("input", &input_blob))
    {
        input_blob_ = input_blob.get();
    }
    else    // NOLINT
#endif
    {
        input_blob_ = net_->input_blobs()[0];
    }

#if 1
    boost::shared_ptr<caffe::Blob<float>> output_blob;
    if (getBlobByName("prob", &output_blob))
    {
        output_blob_ = output_blob.get();
    }
    else    // NOLINT
#endif
    {
        output_blob_ = net_->output_blobs()[0];
    }

    CHECK_EQ(input_blob_->num(), 1);
    CHECK_EQ(output_blob_->num(), 1);

    int rows = input_blob_->height();
    int cols = input_blob_->width();
    float *data = net_->input_blobs()[0]->mutable_cpu_data();
    for (int i = 0; i < input_blob_->channels(); i++)
    {
        cv::Mat m(rows, cols, CV_32FC1, data);
        input_data_.push_back(m);
        data += rows*cols;
    }

    return true;
}

void CnnCaffe::forward(const cv::Mat &image,
                       std::vector<cv::Mat> *result)
{
    CHECK_NOTNULL(result);
    result->clear();

    CHECK_EQ(image.channels(), input_blob_->channels());
    CHECK_EQ(image.rows, input_blob_->height());
    CHECK_EQ(image.cols, input_blob_->width());

    cv::Mat input_image = image;
    if (input_image.depth() != CV_32F)
    {
        input_image.convertTo(input_image, CV_32F);
    }

    input_blob_->mutable_cpu_data();
    cv::split(input_image, input_data_);

    net_->ForwardPrefilled();

    float *data = output_blob_->mutable_cpu_data();
    for (int i = 0; i < output_blob_->channels(); i++)
    {
        cv::Mat m(output_blob_->height(), output_blob_->width(),
                  CV_32FC1, data);
        cv::Mat m2;
        m.convertTo(m2, CV_8U, 255);
        result->push_back(m2);

        data += output_blob_->height()*output_blob_->width();
    }
}

bool CnnCaffe::getBlobByName(
        const std::string &blob_name,
        boost::shared_ptr<caffe::Blob<float>> *blob)
{
    CHECK_NOTNULL(blob);

    *blob = net_->blob_by_name(blob_name);

    return blob->get() != nullptr;
}

bool CnnCaffe::getBlobShapeByName(
        const std::string &blob_name,
        std::vector<int> *blob_shape)
{
    CHECK_NOTNULL(blob_shape);

    boost::shared_ptr<caffe::Blob<float>> blob;
    bool res = getBlobByName(blob_name, &blob);
    if (res)
    {
        *blob_shape = blob->shape();
    }

    return res;
}

bool CnnCaffe::setBlobShapeByName(
        const std::string &blob_name,
        const std::vector<int> &blob_shape)
{
    boost::shared_ptr<caffe::Blob<float>> blob;
    bool res = getBlobByName(blob_name, &blob);
    if (res)
    {
        blob->Reshape(blob_shape);
    }

    return res;
}

}  // namespace tt

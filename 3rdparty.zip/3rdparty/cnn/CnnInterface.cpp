/**
 * @file CnnInterface.cpp
 * @author: Kuang Fangjun <csukuangfj at gmail dot com>
 * @date August 10, 2018
 */

#include <string>

#include "cnn/CnnCaffe.h"
#include "cnn/CnnInterface.h"

namespace tt
{

std::shared_ptr<CnnInterface> CnnInterface::create(
        const std::string &type)
{
    std::shared_ptr<CnnInterface> res;
    if (type == "caffe")
    {
        res.reset(new CnnCaffe());
    }
    else    // NOLINT
    {
        LOG(FATAL) << "Unknown type: " << type
                   << "\nOnly the following types:\n"
                   << "caffe"
                   << "\nare supported";
    }

    return res;
}

}  // namespace tt

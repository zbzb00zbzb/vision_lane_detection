/**
 * @file CnnInterface.h
 * @author: Kuang Fangjun <csukuangfj at gmail dot com>
 * @date August 10, 2018
 *
 */

#ifndef LANE_LINE_CNNINTERFACE_H
#define LANE_LINE_CNNINTERFACE_H

#include <opencv2/core.hpp>

#include <caffe/caffe.hpp>

#include <string>
#include <vector>

namespace tt
{

/**
 * Abstract class for CNN.
 */
class CnnInterface
{
 public:
    static std::shared_ptr<CnnInterface> create(const std::string &type);
 public:
    virtual ~CnnInterface() = default;
    /**
     * @param proto_file   [in] The prototxt.
     * @param trained_file [in] The trained file, i.e., the weight.
     * @param gpu_id       [in] GPU id. Negative values to use CPU.
     * @return true if initialized successfully, false otherwise.
     */
    virtual bool init(
            const std::string &proto_file,
            const std::string &trained_file,
            int gpu_id) = 0;

    /**
     * Predict the image.
     * @param image  [in]
     * @param result [out]
     */
    virtual void forward(const cv::Mat &image,
                         std::vector<cv::Mat> *result) = 0;
    /**
     * @param blob_name [in] the blob name
     * @param blob      [out] the blob
     * @return true if the given blob exists, false otherwise.
     *
     * @note We use boost::shared_ptr instead of std::shared_ptr
     * here because Caffe uses it internally.
     */
    virtual bool getBlobByName(
            const std::string &blob_name,
            boost::shared_ptr<caffe::Blob<float>> *blob) = 0;

    /**
     *
     * @param blob_name [in]
     * @param blob_shape [out]
     * @return true if the given blob exists, false otherwise.
     */
    virtual bool getBlobShapeByName(
            const std::string &blob_name,
            std::vector<int> *blob_shape) = 0;

    /**
     *
     * @param blob_name [in]
     * @param blob_shape [out]
     * @return true if the given blob exists, false otherwise.
     */
    virtual bool setBlobShapeByName(
            const std::string &blob_name,
            const std::vector<int> &blob_shape) = 0;
};

}  // namespace tt

#endif  // LANE_LINE_CNNINTERFACE_H
